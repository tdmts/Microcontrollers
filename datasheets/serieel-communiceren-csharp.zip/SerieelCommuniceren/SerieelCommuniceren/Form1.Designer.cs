﻿
namespace SerieelCommuniceren
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonConnect = new System.Windows.Forms.Button();
            this.buttonDisconnect = new System.Windows.Forms.Button();
            this.buttonZenden1 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.buttonZenden2 = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.labelOntvangen = new System.Windows.Forms.Label();
            this.buttonOntvangen = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // buttonConnect
            // 
            this.buttonConnect.Location = new System.Drawing.Point(6, 32);
            this.buttonConnect.Name = "buttonConnect";
            this.buttonConnect.Size = new System.Drawing.Size(145, 34);
            this.buttonConnect.TabIndex = 0;
            this.buttonConnect.Text = "Connect";
            this.buttonConnect.UseVisualStyleBackColor = true;
            this.buttonConnect.Click += new System.EventHandler(this.buttonConnect_Click);
            // 
            // buttonDisconnect
            // 
            this.buttonDisconnect.Location = new System.Drawing.Point(157, 32);
            this.buttonDisconnect.Name = "buttonDisconnect";
            this.buttonDisconnect.Size = new System.Drawing.Size(145, 34);
            this.buttonDisconnect.TabIndex = 1;
            this.buttonDisconnect.Text = "Disconnect";
            this.buttonDisconnect.UseVisualStyleBackColor = true;
            this.buttonDisconnect.Click += new System.EventHandler(this.buttonDisconnect_Click);
            // 
            // buttonZenden1
            // 
            this.buttonZenden1.Location = new System.Drawing.Point(6, 32);
            this.buttonZenden1.Name = "buttonZenden1";
            this.buttonZenden1.Size = new System.Drawing.Size(145, 33);
            this.buttonZenden1.TabIndex = 2;
            this.buttonZenden1.Text = "LED Aan";
            this.buttonZenden1.UseVisualStyleBackColor = true;
            this.buttonZenden1.Click += new System.EventHandler(this.buttonZenden1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.buttonDisconnect);
            this.groupBox1.Controls.Add(this.buttonConnect);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(314, 78);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Verbinding";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.buttonZenden2);
            this.groupBox2.Controls.Add(this.buttonZenden1);
            this.groupBox2.Location = new System.Drawing.Point(12, 96);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(314, 82);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "PC naar Arduino";
            // 
            // buttonZenden2
            // 
            this.buttonZenden2.Location = new System.Drawing.Point(157, 32);
            this.buttonZenden2.Name = "buttonZenden2";
            this.buttonZenden2.Size = new System.Drawing.Size(145, 33);
            this.buttonZenden2.TabIndex = 3;
            this.buttonZenden2.Text = "LED Uit";
            this.buttonZenden2.UseVisualStyleBackColor = true;
            this.buttonZenden2.Click += new System.EventHandler(this.buttonZenden2_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.labelOntvangen);
            this.groupBox3.Controls.Add(this.buttonOntvangen);
            this.groupBox3.Location = new System.Drawing.Point(12, 184);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(314, 113);
            this.groupBox3.TabIndex = 5;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Arduino naar PC";
            // 
            // labelOntvangen
            // 
            this.labelOntvangen.Location = new System.Drawing.Point(6, 79);
            this.labelOntvangen.Name = "labelOntvangen";
            this.labelOntvangen.Size = new System.Drawing.Size(296, 23);
            this.labelOntvangen.TabIndex = 3;
            this.labelOntvangen.Text = "...";
            // 
            // buttonOntvangen
            // 
            this.buttonOntvangen.Location = new System.Drawing.Point(6, 32);
            this.buttonOntvangen.Name = "buttonOntvangen";
            this.buttonOntvangen.Size = new System.Drawing.Size(296, 33);
            this.buttonOntvangen.TabIndex = 2;
            this.buttonOntvangen.Text = "Ontvangen";
            this.buttonOntvangen.UseVisualStyleBackColor = true;
            this.buttonOntvangen.Click += new System.EventHandler(this.buttonOntvangen_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(341, 309);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Serieel communiceren";
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonConnect;
        private System.Windows.Forms.Button buttonDisconnect;
        private System.Windows.Forms.Button buttonZenden1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label labelOntvangen;
        private System.Windows.Forms.Button buttonOntvangen;
        private System.Windows.Forms.Button buttonZenden2;
    }
}

