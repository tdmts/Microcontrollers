﻿using System;
using System.IO.Ports;
using System.Windows.Forms;

namespace SerieelCommuniceren
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Globale variabele serialPort
        private SerialPort serialPort = new SerialPort();

        private void buttonConnect_Click(object sender, EventArgs e)
        {
            serialPort.PortName = "COMX"; //Veranderen naar juiste poortnummer.
            serialPort.BaudRate = 9600; //Veranderen naar juiste baudrate.

            serialPort.Parity = Parity.None;
            serialPort.DataBits = 8;
            serialPort.StopBits = StopBits.One;
            serialPort.Handshake = Handshake.None;
            
            serialPort.DtrEnable = false; //Afhankelijk van het type Arduino.
            serialPort.RtsEnable = false; //Afhankelijk van het type Arduino.

            //Serial.println() op de Arduino sluit elke lijn af met \r\n.
            //Zonder deze regel blijft die \r aan het antwoord plakken.
            serialPort.NewLine = "\r\n";

            //Antwoordt de Arduino niet, dan blijft ReadLine anders eeuwig wachten
            //en hangt het venster vast.
            serialPort.ReadTimeout = 2000;

            serialPort.Open();
            MessageBox.Show("Verbinding gemaakt.");
        }

        private void buttonDisconnect_Click(object sender, EventArgs e)
        {
            serialPort.Close();
            MessageBox.Show("Verbinding verbroken.");
        }

        private void buttonZenden1_Click(object sender, EventArgs e)
        {
            serialPort.WriteLine("LED:1");
        }

        private void buttonZenden2_Click(object sender, EventArgs e)
        {
            serialPort.WriteLine("LED:0");
        }

        private void buttonOntvangen_Click(object sender, EventArgs e)
        {
            serialPort.WriteLine("SENSOR:?");
            string waarde = serialPort.ReadLine();

            labelOntvangen.Invoke((MethodInvoker)(() => 
                labelOntvangen.Text = waarde
                ));
        }

        
    }
}
